import aiohttp
import asyncio

async def test_api(url, headers, data, num):
    # 创建一个连接池
    async with aiohttp.ClientSession() as session:
        # 创建一个请求列表
        requests = []
        for _ in range(num):
            requests.append(session.post(url=url, headers=headers, json=data))

        # 并发发送请求
        responses = await asyncio.gather(*requests)

        # 处理响应结果
        results = []
        for response in responses:
            response_data = await response.json()
            result= (response.status,response_data)
            results.append(result)
    return results

def call_test_api(url, headers, data, num):
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    a = loop.run_until_complete(test_api(url, headers, data, num))
    return a
