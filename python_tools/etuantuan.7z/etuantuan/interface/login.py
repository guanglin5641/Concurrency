import commen.Concurrency
def to_examine(token,promotion_order_id,order_status,num):

    Url = 'https://bwc.ds44.top/adminapi/hp_rec.hp_rec/audit'
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36 Edg/119.0.0.0",
        "Accept": "application/json, text/plain, */*",
        "Accept-Encoding": "gzip, deflate, br",
        "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6",
        "Cache-Control": "no-cache",
        "Origin": "https://bwc.ds44.top",
        "Pragma": "no-cache",
        "Referer": "https://bwc.ds44.top/admin/ett/hp_rec/lists",
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "same-origin",
        "sec-ch-ua": "\"Microsoft Edge\";v=\"119\", \"Chromium\";v=\"119\", \"Not?A_Brand\";v=\"24\"",
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": "\"Windows\"",
        "token": token,
        "version": "2.4.0"
    }
    data = {
        "promotion_order_id": promotion_order_id,
        "order_status": order_status
    }
    a = commen.Concurrency.call_test_api(Url, headers, data, num)
    return (a)


if __name__ == '__main__':
    token = "09e6aa6e29e7bbae7193459920f42863"
    promotion_order_id = 11572
    order_status = 3
    num = 2
    print(to_examine(token,promotion_order_id,order_status,num))
